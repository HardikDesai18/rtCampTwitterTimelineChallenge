<?php
phpinfo();	
?>