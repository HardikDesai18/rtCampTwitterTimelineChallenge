<?php 

 include_once('TwitterAPIExchange.php');
 
 $twitter_consumer_key = theme_get_setting('twitter_consumer_key'); 
     
 $twitter_consumer_secret = theme_get_setting('twitter_consumer_secret');   
 
 $twitter_access_token = theme_get_setting('twitter_access_token'); 
 
 $twitter_access_token_secret = theme_get_setting('twitter_access_token_secret'); 
  
 $twitter_id = theme_get_setting('twitter_id'); 
     
 $twitter_count = theme_get_setting('twitter_no_tweet'); 
 
 $twitter_cp_count = theme_get_setting('twitter_baincp_no_tweet'); 

 if($twitter_id && $twitter_consumer_key && $twitter_consumer_secret && $twitter_access_token && $twitter_access_token_secret && $twitter_count) {
     $settings = array(
    'oauth_access_token' => $twitter_access_token,
    'oauth_access_token_secret' => $twitter_access_token_secret,
    'consumer_key' => $twitter_consumer_key,
    'consumer_secret' => $twitter_consumer_secret
    );
     		 	
	$url = 'https://api.twitter.com/1.1/statuses/user_timeline.json';
	$getfield = '?username='.$twitter_id.'&count='.$twitter_count;
		
	$requestMethod = 'GET';
    $twitter = new TwitterAPIExchange($settings);
    
    $tweets = $twitter->setGetfield($getfield)
             ->buildOauth($url, $requestMethod)
             ->performRequest();  
    
    $tweets_arr = json_decode($tweets);
	$customtweet_array = array();
	$alltweet_array = array();
	$tweetarray	= array();

		/*$i = 1;
		$theme_val = $twitter_count;*/
		
	foreach($tweets_arr as $each_tweets){
			

			$tweetpos = strpos($each_tweets->text, '#BainCapitalCP'); 
			
				$pos = strpos($each_tweets->text, 'https://'); 
				$tweet_text = substr($each_tweets->text, 0, $pos); 
				$tweet_url = substr($each_tweets->text, $pos); 
				
				$redirect_url = $each_tweets->entities->urls[0]->url;
				$tweetarray['date'] = date("m/d/y", strtotime($each_tweets->created_at));
				$tweetarray['tweet_text'] = $tweet_text;
				$tweetarray['redirect_url'] = $redirect_url;
				$tweetarray['tweet_url']	=	$tweet_url;
				if($tweetpos != FALSE) {
					array_push($customtweet_array,$tweetarray);				
				} 
				array_push($alltweet_array,$tweetarray);
		}
		$tweets_arr = $alltweet_array;
} 
?>
 