<?php

define('SECURE',TRUE);

?>
