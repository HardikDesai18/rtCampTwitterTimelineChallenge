$(document).ready(function() {
 
  var owl = $("#owl-demo");
 
  owl.owlCarousel({
    navigation : true,
    singleItem : true,
    transitionStyle : "fade"
  });
 
});