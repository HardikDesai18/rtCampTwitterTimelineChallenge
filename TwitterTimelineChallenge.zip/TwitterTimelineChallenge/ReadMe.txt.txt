In this Twitter Timeline challenge i have done following work :

i)created access token for twitter account : @hardikdesaii
ii)Consumer Key (API Key):8yM23w2h2ztc4tTzlRaBzbIbl

iii)Consumer Secret (API Secret):ec55lCy8aAWxIbHfijLVbp8Ord5E7NhXD3pLGExsXtMmIRiydb

iv)Access Token:753102090-R1x29O155V40IR29mtfGM3xw7wf5snweRLdfGGPv

v)Access Token Secret:6oGUlstLxKJ5gxnmKd1YgFuvLQk5S5QKl9EkpGVubMaou
vi) using cURL i have fetched 10 tweets from account @hardikdesaii
vii) used bootstrap corousal owl to show 10 tweets on my page 